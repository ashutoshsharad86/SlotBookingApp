package com.ashutosh.slotbookingapp;

import java.lang.reflect.Type;
import java.util.Map;
import java.util.Set;

import com.google.gson.JsonArray;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;

public class SlotTimingsDesrializer implements JsonDeserializer<SlotTimingItems> {

    @Override
    public SlotTimingItems deserialize(final JsonElement json, final Type typeOfT, final JsonDeserializationContext context)
            throws JsonParseException {
        final JsonObject jsonObject = json.getAsJsonObject();
        final JsonObject slotObject = jsonObject.getAsJsonObject("slots");
        SlotTimingItems slotTimingItems = new SlotTimingItems();
        for(Map.Entry<String, JsonElement> entry : slotObject.entrySet()) {
            Timings_Days timings_days = context.deserialize(entry.getValue(),Timings_Days.class);
            slotTimingItems.getSlots_per_day().put(entry.getKey(), timings_days);
        }
        return slotTimingItems;
    }
}