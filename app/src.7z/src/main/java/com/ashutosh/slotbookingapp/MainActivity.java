package com.ashutosh.slotbookingapp;

import android.app.ProgressDialog;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity implements Callback<SlotTimingItems> {
    public ProgressDialog progress_horizontal;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle(null);
        Toolbar topToolBar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(topToolBar);

        TabsPagerAdapter adapter = new TabsPagerAdapter(getSupportFragmentManager());
        ViewPager pager = (ViewPager) findViewById(R.id.pager);
        pager.setAdapter(adapter);


        callForSlotsNow();
        progress_horizontal = new ProgressDialog(MainActivity.this);
        progress_horizontal.setMessage("Getting all slots, please wait ...");
        progress_horizontal.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        progress_horizontal.setIndeterminate(true);
        progress_horizontal.setCancelable(false);
        progress_horizontal.show();


    }

    public void callForSlotsNow() {

        System.out.println("Request fired");
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://108.healthifyme.com")
                .addConverterFactory(GsonConverterFactory.create())
                .build();



        // prepare call in Retrofit 2.0
        HealthifyMeInterface slotTimingsItemsGet = retrofit.create(HealthifyMeInterface.class);
        Call<SlotTimingItems> call = slotTimingsItemsGet.loadQuestions();
        call.enqueue(this);

    }

    @Override
    public void onResponse(Call<SlotTimingItems> call,Response<SlotTimingItems> response) {
        System.out.println();

    }

    @Override
    public void onFailure(Call<SlotTimingItems> call, Throwable t) {
        Toast.makeText(MainActivity.this, t.getLocalizedMessage(), Toast.LENGTH_SHORT).show();
    }

    private static GsonConverterFactory buildGsonConverter() {
        GsonBuilder gsonBuilder = new GsonBuilder();
        gsonBuilder.registerTypeAdapter(SlotTimingItems.class, new SlotTimingsDesrializer());
        Gson myGson = gsonBuilder.create();

        return GsonConverterFactory.create(myGson);
    }





}
